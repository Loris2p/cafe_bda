import 'package:cafe_bda/providers/auth_provider.dart';
import 'package:cafe_bda/providers/cafe_data_provider.dart';
import 'package:cafe_bda/repositories/cafe_repository.dart';
import 'package:cafe_bda/services/auth_service.dart';
import 'package:cafe_bda/services/google_sheets_service.dart';
import 'package:cafe_bda/services/firebase_service.dart';
import 'package:cafe_bda/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';
import 'screens/google_sheets_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

/// Point d'entrée de l'application Gestion Café BDA.
///
/// Initialise les liaisons Flutter, charge les variables d'environnement,
/// et configure l'injection de dépendances globale via le package `provider`.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  try {
    await dotenv.load(fileName: ".env");
  } catch (e) {
    print("Erreur critique lors du chargement du fichier .env: $e");
  }

  // Initialisation des services et repositories (Singletons)
  final authService = AuthService();
  final sheetsService = GoogleSheetsService();
  final firebaseService = FirebaseService();
  final cafeRepository = CafeRepository(sheetsService, firebaseService);

  runApp(
    MultiProvider(
      providers: [
        // Injection des Services et du Repository
        Provider<AuthService>.value(value: authService),
        Provider<GoogleSheetsService>.value(value: sheetsService),
        Provider<FirebaseService>.value(value: firebaseService),
        Provider<CafeRepository>.value(value: cafeRepository),
        
        // Providers gérant l'état
        ChangeNotifierProvider(
          create: (_) => AuthProvider(authService, sheetsService),
        ),
        ChangeNotifierProvider(
          create: (_) => CafeDataProvider(cafeRepository, sheetsService),
        ),
      ],
      child: const MyApp(),
    ),
  );
}

/// Widget racine de l'application.
///
/// Configure le thème global et définit l'écran initial.
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<CafeDataProvider>(
      builder: (context, cafeDataProvider, child) {
        return MaterialApp(
          title: 'Gestion Café BDA',
          theme: AppTheme.getTheme(isAdmin: cafeDataProvider.isAdminMode),
          home: const GoogleSheetsScreen(),
          debugShowCheckedModeBanner: false,
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: const [
            Locale('fr', 'FR'), // Français
          ],
        );
      },
    );
  }
}
